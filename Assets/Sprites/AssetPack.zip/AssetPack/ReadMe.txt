Hello and welcome on this asset pack!

First thing first: thanks a lot for the purchase!! 
I really hope you'll enjoy making games with this cute character :)

If you need some modifications or extra content, I'm currently not available enough so I recommand you to contact other pixel artists!
Here is a list I've made with artists I personnaly know and recommand (some of them were my students!):
https://twitter.com/i/lists/1348921662146830339/members
Hope it'll help!

For commercial use, no extra-fees, feel free to use it as you want :)


Thanks again and have fun!



Thomas Lean